JAYEMATH WATER PROJECT V185 - CLEAN APK PROJECT

This clean source keeps the V185 web app data/features and prepares it for Android APK build without Android Studio.

Included:
- Existing V185 billing/customers/payments/reports/SMS/Supabase/staff/water-cut/meter features from the saved V185 index.html.
- V185 tariff: Fixed Rs.50; 1-20 Rs.20; 21-30 Rs.25; 31-50 Rs.50; 51+ Rs.100.
- Account-number/address search logic including account 96 support.
- Meter replacement with new meter starting reading.
- Staff request/approval/revoke workflow.
- XP-P301A Bluetooth ESC/POS native Android bridge.
- Browser Web Serial printing remains available for PC/Chrome/Edge.
- GitHub Actions workflow builds a debug APK using Java 17 + Gradle 8.7.

HOW TO BUILD:
1. Upload this project to the GitHub repository.
2. Open Actions.
3. Run "Build Jayemath APK" with "Run workflow".
4. Download the artifact "jayemath-water-project-v185-apk".
5. Inside it, install the generated app-debug.apk on Android.

ANDROID PRINTER:
1. Pair XP-P301A in Android Bluetooth settings.
2. Open the APK.
3. Go to Printer Setup.
4. Tap "Connect Xprinter Bluetooth / COM".
5. Select the paired XP-P301A.
6. Tap Test Print.

IMPORTANT:
- No Android Studio is required for the GitHub Actions build.
- The Supabase URL/key are included in config.js from the existing V185 project.
